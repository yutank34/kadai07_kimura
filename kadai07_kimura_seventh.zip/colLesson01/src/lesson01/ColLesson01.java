package lesson01;
import java.util.Scanner;

class MyException extends Exception{
	public MyException(String s){
		super(s);
	}
}

public class ColLesson01 {
	public static void main(String[] args) {
		// Wordクラスのインスタンス配列
		int num = 10; //配列の要素数を指定
		Word[] words = new Word[num];

		// コマンドラインから入力
		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");
		Scanner sc  = new Scanner(System.in);
		String input = sc.nextLine();

		// ここから記述してください
		// 例えば、「apple  りんご」と入力されたときはtmp[0]に"apple"、tmp[1]に"りんご"が入る
		int index = 0;
		try{
			while(index < num && !input.equals("e")){
				String[] tmp = input.split("[ 　]",2);
				if(tmp.length < 2){
					throw new MyException("入力エラー：スペース区切りで単語を登録");
				}
				words[index] = new Word(tmp[0], tmp[1]);
				index++;
				if(index < num){
					System.out.println("次の英単語と日本語を入力して下さい。\"e\"で終了します。");
					input = sc.nextLine();
				}
			}
		}
		catch(MyException e){
			e.printStackTrace();
			System.out.println("単語を二つ入力してください\n登録済みのデータは以下になります。");
		}
		finally{
			for(int i = 0; i < index; i++){
				System.out.println("英単語： " + words[i].getEnglish() + "　日本語： " + words[i].getJapanese());
			}
			System.out.println(index + "件、登録しました。");
		}
	}
}

