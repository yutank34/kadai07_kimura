package lesson03;

public class Word{
	private String english;
	private String japanese;

	public String getEnglish(){
		return this.english;
	}
	public String setEnglish(String english){
		return this.english;
	}
	public String getJapanese(){
		return this.japanese;
	}
	public String setJapanese(String japanese){
		return this.japanese;
	}

	public Word(String english, String japanese){
		this.english = english;
		this.japanese = japanese;
	}

	public String toString(){
		return "英単語： " + this.english + "　日本語： " + this.japanese;
	}
}