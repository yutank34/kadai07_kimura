package dblesson01;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DBLesson01{
	public static void main(String[] args){
		List<Word> words = new ArrayList<>();
		WordDAO dao = new WordDAO();

		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();

		while(!input.equals("e")){
			String[] tmp = input.split("[ 　]",2);
			words.add(new Word(tmp[0], tmp[1]));
			System.out.println("次の英単語と日本語を入力して下さい。\"e\"で終了します。");
			input = sc.nextLine();
		}

		int count = dao.registWords(words);
		System.out.println(count + "件の登録が完了しました。");

	}
}