package lesson02;
import java.util.Scanner;

class MyException extends Exception{
	public MyException(String s){
		super(s);
	}
}

public class ColLesson02{
	public static void main(String[] args){
		int num = 10; //配列の要素数を指定
		Word[] words = new Word[num];

		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();

		int index = 0;
		try{
			while(index < num && !input.equals("e")){
				String[] tmp = input.split("[ 　]",2);
				if(tmp.length < 2){
					throw new MyException("入力エラー：スペース区切りで単語を登録");
				}
				words[index] = new Word(tmp[0], tmp[1]);
				index++;
				if(index < num){
					System.out.println("次の英単語と日本語を入力して下さい。\"e\"で終了します。");
					input = sc.nextLine();
				}
			}
		}
		catch(MyException e){
			e.printStackTrace();
			System.out.println("単語を二つ入力してください。\n登録済みの単語は以下になります。");
		}
		finally{
			for(int i = 0; i < index; i++){
				System.out.println(words[i].toString());
			}
			System.out.println(index + "件、登録しました。");
		}
	}
}