package lesson03;
import java.util.Scanner;

class MyException extends Exception{
	public MyException(String s){
		super(s);
	}
}

public class ColLesson03{
	public static void main(String[] args){
		int num = 5; //配列の要素数を指定
		Word[] words = new Word[num];

		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();

		int index = 0;
		try{
			while(!input.equals("e")){
				String[] tmp = input.split("[ 　]",2);
				if(tmp.length != 2){
					throw new MyException("入力エラー：スペース区切りで単語を登録");
				}
				words[index] = new Word(tmp[0], tmp[1]);
				index++;
				System.out.println("次の英単語と日本語を入力して下さい。\"e\"で終了します。");
				input = sc.nextLine();
			}
		}
		catch(ArrayIndexOutOfBoundsException e){
//			e.printStackTrace();
			System.out.println("登録制限を越えました。登録済みのデータは以下になります。");
		}
		catch(MyException e){
			System.out.println("一つしか単語が入力されていません。");
		}
		finally{
			for(int i = 0; i < index; i++){
				System.out.println(words[i].toString());
			}
			System.out.println(index + "件、登録しました。");
		}
	}
}